#pragma once
#include "Weapon.h"
class Hammer :public Weapon
{
public:

	int Attack(int Character_Demage);
	Hammer();
	~Hammer();
};

