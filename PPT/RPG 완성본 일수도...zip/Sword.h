#pragma once
#include "Weapon.h"
class Sword : public Weapon
{
public:

	int Attack(int Character_Demage);

	Sword();	
	~Sword();
};

