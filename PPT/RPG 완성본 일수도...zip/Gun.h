#pragma once
#include "Weapon.h"
class Gun : public Weapon
{
public:

	int Attack(int Character_Demage);
	Gun();
	~Gun();
};

