#pragma once
#include "Weapon.h"
class Wand : public Weapon
{
public:
	Wand();
	int Attack(int Character_Demage);
	~Wand();
};

