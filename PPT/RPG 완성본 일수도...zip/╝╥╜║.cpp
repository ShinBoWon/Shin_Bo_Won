#include "GamePlay.h"

void main()
{
	GamePlay P1;
	P1.Map();
}