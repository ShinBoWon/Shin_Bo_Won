#pragma once
#include "Weapon.h"
class Dagger : public Weapon
{
public:

	int Attack(int Character_Demage);
	Dagger();
	~Dagger();
};

